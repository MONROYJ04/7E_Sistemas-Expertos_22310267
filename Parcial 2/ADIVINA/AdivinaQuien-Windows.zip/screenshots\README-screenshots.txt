Carpeta de capturas de pantalla

Aquí puedes colocar imágenes para la página de itch.io. Recomendación:
- Usa imágenes 1280x720 para la cabecera y miniaturas.
- Capturas sugeridas:
  1) Menú principal mostrando lista de personajes.
  2) Pantalla de pregunta en juego.
  3) Pantalla de victoria cuando adivina el personaje.

Cómo crear capturas en Windows:
- Abre el juego y ajusta la ventana a un tamaño decente.
- Pulsa Win+Shift+S para usar el recorte, guarda las imágenes en esta carpeta.
- Nombra los archivos: screenshot1.png, screenshot2.png, screenshot3.png

Si quieres, puedo generar imágenes de ejemplo en blanco con etiquetas, pero es mejor que uses capturas reales del juego para la página.