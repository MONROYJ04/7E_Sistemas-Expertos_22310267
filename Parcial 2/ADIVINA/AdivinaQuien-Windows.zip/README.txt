﻿Adivina QuiÃ©n - Naruto Edition (Windows)
======================================
Instrucciones:
1) Extrae el ZIP en una carpeta.
2) Ejecuta AdivinaQuien.exe para iniciar el juego.
3) AsegÃºrate de que cualquier archivo .json estÃ© en la misma carpeta que el exe si el juego lo requiere.
